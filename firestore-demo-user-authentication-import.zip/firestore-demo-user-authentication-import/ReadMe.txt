
Demo User Authentication Import

Command :

1) Get serviceAccountKey.json from firbase configuration
	link:https://clemfournier.medium.com/how-to-get-my-firebase-service-account-key-file-f0ec97a21620

2) npm install
	
3) run command: "node import-user.js"
