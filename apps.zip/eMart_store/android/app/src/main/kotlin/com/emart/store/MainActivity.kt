package com.emart.store



import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
